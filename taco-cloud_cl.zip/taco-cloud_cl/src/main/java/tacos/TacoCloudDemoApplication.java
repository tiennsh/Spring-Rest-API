package tacos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TacoCloudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TacoCloudDemoApplication.class, args);
	}

}
